#include <stdlib.h>
#include <stdio.h>

void main(void)
{

	printf("/************************/\n");
	printf("/*���: 2020/9/15\t*/\n");
	printf("/*�Ǹ�: 1060644\t\t*/\n");
	printf("/*���: ���ç�\t\t*/\n");
	printf("/************************/\n");

	system("pause");

}