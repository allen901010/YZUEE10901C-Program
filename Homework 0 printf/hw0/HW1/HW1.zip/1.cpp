#include <stdlib.h>
#include <stdio.h>

void main(void)
{

	printf("             \"\"\"\"\n");
	printf("	      \"\"\"\"\"\"\"\n");
	printf("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%\"\"\"\"\"\"\"\"\"\n");
	printf("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%\"\"\"\"\"\"\"\"\"\"\"\"\n");
	printf("               \"\"\"\"\"\"\"\"\"\n");
	printf("	      \"\"\"\"\"\"\"\n");
	printf("             \"\"\"\"\n");


	system("pause");
}